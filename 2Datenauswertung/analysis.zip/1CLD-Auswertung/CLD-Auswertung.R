#--- R-Einstellungen
getwd()
setwd("/home/marc/Dokumente/Bachelorarbeit/")
options(max.print=500000)

#--- Molare Masse des Monomers
M_BuA <- 128.17
M_BuA

#--- Haeufigkeitstabellen der Kettenlaengenverteilung: 1e11 Molekuele, Ordner sim1, Zeitpunkt 600 und 3600 Sekunden
pdf(file = "e11_CLD_600.pdf")
e11.CLD.600 <- read.table("1Datenbasis/1e11/sim1/D.600.0.cld", header=T, skip=6)# Haeufigkeitstabelle einlesen
plot(e11.CLD.600[,1:2])# Polymerkettenlaengen und deren absolute Haeufigkeit plotten
dev.off()

pdf(file = "e11_CLD_3600.pdf")
e11.CLD.3600 <- read.table("1Datenbasis/1e11/sim1/D.3600.0.cld", header=T, skip=6)# Haeufigkeitstabelle einlesen
e11.CLD.3600[,1:2]#  
plot(e11.CLD.3600[,1:2])# Polymerkettenlaengen und deren absolute Haeufigkeit plotten
dev.off()

#--- Plot der Verteilung der molaren Masse nach 3600 Sekunden
pdf(file = "e11_M_3600.pdf")
e11.M.3600 <- read.table("1Datenbasis/1e11/sim1/D.3600.0.cld", header=T, skip=6)# Haeufigkeitstabelle einlesen
e11.M.3600[,1] <- e11.M.3600[,1]*M_BuA
plot(e11.M.3600[,1:2], ylab="absolute Häufigkeit", xlab="Molare Masse in g/mol")
abline(v=7287.53, col="black")# Mn,3600 einzeichnen
abline(v=15370.76, col="black")# Mw,3600 einzeichnen
text(0, 500000, expression(bar(M[n])), col = "black")# Mn,3600 Bezeichnung positionieren
text(22000, 500000, expression(bar(M[w])), col = "black")# Mw,3600 Bezeichnung positionieren
dev.off()