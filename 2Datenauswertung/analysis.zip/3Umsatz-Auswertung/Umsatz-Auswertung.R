#--- R-Einstellungen
getwd()
setwd("/home/marc/Dokumente/Bachelorarbeit/")
options(max.print=500000)

#--- Zeitpunkte der Simulation in Sekunden
time <- c(120,600,1200,1800,2400,3000,3600)
time

#--- Einlesen von Daten: 1e11 Molekuele, Ordner sim1 bis sim1000
e11.foldernum <- seq(1,1000,1)
e11.foldername <- character(1000)
e11.foldername <- paste("sim",e11.foldernum,sep="")
e11.c <- numeric(14000)
counter.values <- 1
for(e11.j in 1:1000){
  e11.sim.c <- numeric(14)
  rows <- c(13,61,121,181,241,301,361)
  counter <- 1
    for(i in 1:7){
      e11.sim.con <-  read.table(paste("1Datenbasis/1e11/",e11.foldername[e11.j],"/","cBuA.0.dat",sep=""), header=T, sep = "\t")
      e11.sim.c[counter] <- e11.sim.con[rows[i],3]
      counter <- counter+1
      e11.sim.con <-  read.table(paste("1Datenbasis/1e11/",e11.foldername[e11.j],"/","cBuA.0.dat",sep=""), header=T, sep = "\t")
      e11.sim.c[counter] <- (e11.sim.con[1,3]-e11.sim.con[rows[i],3])/(e11.sim.con[1,3])
      counter <- counter+1
    }
  e11.sim.c
  e11.c[counter.values:(counter.values+13)] <- e11.sim.c
  counter.values <- counter.values+14
}
e11.c <- matrix(e11.c, nrow=1000, ncol=14, byrow=T)

#--- Einlesen von Daten: 5e10 Molekuele, Ordner sim1 bis sim2673
e10.foldernum <- seq(1,2673,1)
e10.foldername <- character(2673)
e10.foldername <- paste("sim",e10.foldernum,sep="")
e10.c <- numeric(37422)
counter.values <- 1
for(e10.j in 1:2673){
  e10.sim.c <- numeric(14)
  rows <- c(13,61,121,181,241,301,361)
  counter <- 1
  for(i in 1:7){
    e10.sim.con <-  read.table(paste("1Datenbasis/5e10/",e10.foldername[e10.j],"/","cBuA.0.dat",sep=""), header=T, sep = "\t")
    e10.sim.c[counter] <- e10.sim.con[rows[i],3]
    counter <- counter+1
    e10.sim.con <-  read.table(paste("1Datenbasis/5e10/",e10.foldername[e10.j],"/","cBuA.0.dat",sep=""), header=T, sep = "\t")
    e10.sim.c[counter] <- (e10.sim.con[1,3]-e10.sim.con[rows[i],3])/(e10.sim.con[1,3])
    counter <- counter+1
  }
  e10.sim.c
  e10.c[counter.values:(counter.values+13)] <- e10.sim.c
  counter.values <- counter.values+14
}
e10.c <- matrix(e10.c, nrow=2673, ncol=14, byrow=T)

#--- Export der Daten als .csv
e11.c
write.csv2(e11.c,file="2Datenauswertung/3Umsatz-Auswertung/e11.c.csv")
e10.c
write.csv2(e10.c,file="2Datenauswertung/3Umsatz-Auswertung/e10.c.csv")

####################################################################################################

#--- R-Einstellungen
getwd()
setwd("/home/marc/Dokumente/Bachelorarbeit/")
options(max.print=500000)

#--- Zeitpunkte der Simulation in Sekunden
time <- c(120,600,1200,1800,2400,3000,3600)
time

#-- Import der Daten von .csv
e11.c <- read.csv2(file="2Datenauswertung/3Umsatz-Auswertung/e11.c.csv",header=T)
e11.c <- e11.c[,-1]

e10.c <- read.csv2(file="2Datenauswertung/3Umsatz-Auswertung/e10.c.csv",header=T)
e10.c <- e10.c[,-1]

#--- Plot: Verlauf Umsatz fuer sim1 und 1e11 Molekuele
pdf(file="Umsatz_plot.pdf")
plot(time,e11.c[1,c(2,4,6,8,10,12,14)],xlim=(c(0,3600)),ylim=(c(0,1.0)),xaxt="n",xlab="Zeit in Sekunden",ylab="Umsatz des Monomers")
axis(1, at=c(time), labels=c(time))
dev.off()

#--- Boxplots
pdf(file = "Umsatz_box.pdf")
par(mfrow = c(1,3))
boxplot(e11.c[,4],e10.c[,4], ylim=c(0.180,0.187), xlab="A", ylab="Umsatz des Monomers", col=c("lightgray","white"))
boxplot(e11.c[,8],e10.c[,8], ylim=c(0.410,0.417), xlab="B", ylab="Umsatz des Monomers", col=c("lightgray","white"))
boxplot(e11.c[,14],e10.c[,14], ylim=c(0.593,0.600), xlab="C", ylab="Umsatz des Monomers", col=c("lightgray","white"))
dev.off()

#--- Histogramme
pdf(file="Umsatz_hist.pdf")
par(mfrow = c(3,2))
hist(e11.c[,4], freq=F, breaks=seq(0.180,0.187,0.00025), xlim=c(0.180,0.187), ylim=c(0,1000), main="A: Histogramm nach 600 Sekunden", xlab="Umsatz des Monomers", ylab="Dichte", col="lightgray")
lines(density(e11.c[,4], kernel="gaussian"))
hist(e10.c[,4], freq=F, breaks=seq(0.180,0.187,0.00025), xlim=c(0.180,0.187), ylim=c(0,1000), main="A: Histogramm nach 600 Sekunden", xlab="Umsatz des Monomers", ylab="Dichte")
lines(density(e10.c[,4], kernel="gaussian"))
hist(e11.c[,8], freq=F, breaks=seq(0.410,0.417,0.00025), xlim=c(0.410,0.417), ylim=c(0,1000), main="B: Histogramm nach 1800 Sekunden", xlab="Umsatz des Monomers",ylab="Dichte", col="lightgray")
lines(density(e11.c[,8], kernel="gaussian"))
hist(e10.c[,8], freq=F, breaks=seq(0.410,0.417,0.00025), xlim=c(0.410,0.417), ylim=c(0,1000),  main="B: Histogramm nach 1800 Sekunden", xlab="Umsatz des Monomers",ylab="Dichte")
lines(density(e10.c[,8], kernel="gaussian"))
hist(e11.c[,14], freq=F, breaks=seq(0.593,0.600,0.00025), xlim=c(0.593,0.600), ylim=c(0,1000), main="C: Histogramm nach 3600 Sekunden", xlab="Umsatz des Monomers",ylab="Dichte", col="lightgray")
lines(density(e11.c[,14], kernel="gaussian"))
hist(e10.c[,14], freq=F, breaks=seq(0.593,0.600,0.00025), xlim=c(0.593,0.600), ylim=c(0,1000), main="C: Histogramm nach 3600 Sekunden", xlab="Umsatz des Monomers",ylab="Dichte")
lines(density(e10.c[,14], kernel="gaussian"))
dev.off()

#--- Konfidenzintervalle
t.test(e11.c[,4])
set.seed(1724827)
t.test(e10.c$V4[sample(1:2673, replace=F, size=1000)])
t.test(e11.c[,8])
set.seed(2738421)
t.test(e10.c$V8[sample(1:2673, replace=F, size=1000)])
t.test(e11.c[,14])
set.seed(1274921)
t.test(e10.c$V14[sample(1:2673, replace=F, size=1000)])

#--- Zwei-Stichproben-t-Tests
set.seed(2428491)
t.test(e11.c[,4],e10.c$V4[sample(1:2673, replace=F, size=1000)])
set.seed(6219421)
t.test(e11.c[,8],e10.c$V8[sample(1:2673, replace=F, size=1000)])
set.seed(4829130)
t.test(e11.c[,14],e10.c$V14[sample(1:2673, replace=F, size=1000)])

#--- Varianz-Tests
set.seed(3982171)
var.test(e11.c[,4],e10.c$V4[sample(1:2673, replace=F, size=1000)])
set.seed(5124856)
var.test(e11.c[,8],e10.c$V8[sample(1:2673, replace=F, size=1000)])
set.seed(1293241)
var.test(e11.c[,14],e10.c$V14[sample(1:2673, replace=F, size=1000)])