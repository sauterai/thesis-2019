#--- R-Einstellungen
getwd()
setwd("/home/marc/Dokumente/Bachelorarbeit/")
options(max.print=500000)

#--- Molare Masse des Monomers
M_BuA <- 128.17
M_BuA

#--- Zeitpunkte der Simulation in Sekunden
time <- c(120,600,1200,1800,2400,3000,3600)
time

#--- Dateinamen innerhalb einer Simulation
filename <- numeric(7)
for(i in 1:7){
  filename[i] <- paste("D",time[i],"0","cld",sep=".")  
}

#--- Einlesen von Daten: 1e11 Molekuele, Ordner sim1 bis sim1000
e11.foldernum <- seq(1,1000,1)
e11.foldername <- character(1000)
e11.foldername <- paste("sim",e11.foldernum,sep="")
e11.MnMw <- numeric(14000)
counter.values <- 1
for(e11.j in 1:1000){
  e11.sim.MnMw <- numeric(14)
  counter.M <- 1
    for(i in 1:7){
      e11.sim.CLD <- read.table(paste("1Datenbasis/1e11/",e11.foldername[e11.j],"/",filename[i],sep=""), header=T, skip=6)
      e11.sim.Mn <- sum((e11.sim.CLD[,2]*e11.sim.CLD[,1]*M_BuA))/sum(e11.sim.CLD[,2])# Zahlenmittel
      e11.sim.Mw <- sum(e11.sim.CLD[,2]*(e11.sim.CLD[,1]*M_BuA)^2)/sum(e11.sim.CLD[,1]*e11.sim.CLD[,2]*M_BuA)# Gewichtsmittel
      e11.sim.MnMw[counter.M:(counter.M+1)] <- c(e11.sim.Mn,e11.sim.Mw)
      counter.M <- counter.M+2
    }
  e11.sim.MnMw
  e11.MnMw[counter.values:(counter.values+13)] <- e11.sim.MnMw
  counter.values <- counter.values+14
}
e11.MnMw <- matrix(e11.MnMw, nrow=1000, ncol=14, byrow=T)

#--- Einlesen von Daten: 5e10 Molekuele, Ordner sim1 bis sim2673
e10.foldernum <- seq(1,2673,1)
e10.foldername <- character(2673)
e10.foldername <- paste("sim",e10.foldernum,sep="")
e10.MnMw <- numeric(37422)
counter.values <- 1
for(e10.j in 1:2673){
  e10.sim.MnMw <- numeric(14)
  counter.M <- 1
  for(i in 1:7){
    e10.sim.CLD <- read.table(paste("1Datenbasis/5e10/",e10.foldername[e10.j],"/",filename[i],sep=""), header=T, skip=6)
    e10.sim.Mn <- sum((e10.sim.CLD[,2]*e10.sim.CLD[,1]*M_BuA))/sum(e10.sim.CLD[,2])# Zahlenmittel
    e10.sim.Mw <- sum(e10.sim.CLD[,2]*(e10.sim.CLD[,1]*M_BuA)^2)/sum(e10.sim.CLD[,1]*e10.sim.CLD[,2]*M_BuA)# Gewichtsmittel
    e10.sim.MnMw[counter.M:(counter.M+1)] <- c(e10.sim.Mn,e10.sim.Mw)
    counter.M <- counter.M+2
  }
  e10.sim.MnMw
  e10.MnMw[counter.values:(counter.values+13)] <- e10.sim.MnMw
  counter.values <- counter.values+14
}
e10.MnMw <- matrix(e10.MnMw, nrow=2673, ncol=14, byrow=T)

#--- Export der Daten als .csv
e11.MnMw
write.csv2(e11.MnMw,file="2Datenauswertung/2MnMw-Auswertung/e11.MnMw.csv")
e10.MnMw
write.csv2(e10.MnMw,file="2Datenauswertung/2MnMw-Auswertung/e10.MnMw.csv")

####################################################################################################

#--- R-Einstellungen
getwd()
setwd("/home/marc/Dokumente/Bachelorarbeit/")
options(max.print=500000)

#--- Zeitpunkte der Simulation in Sekunden
time <- c(120,600,1200,1800,2400,3000,3600)
time

#-- Import der Daten von .csv
e11.MnMw <- read.csv2(file="2Datenauswertung/2MnMw-Auswertung/e11.MnMw.csv",header=T)
e11.MnMw <- e11.MnMw[,-1]

e10.MnMw <- read.csv2(file="2Datenauswertung/2MnMw-Auswertung/e10.MnMw.csv",header=T)
e10.MnMw <- e10.MnMw[,-1]

#--- Schematische Darstellung eines Boxplots
pdf(file = "Schema_box.pdf")
boxplot(e11.MnMw[,7],ylim=c(8525,8555),xaxt="n",yaxt="n")
axis(1, at=1, labels="")
axis(2, at=c(seq(8525,8555,10)), labels=c("","","",""))
text(x=1.35,y=8551,labels="Ausreißer")
text(x=1.35,y=8543,labels="oberes Quartil")
text(x=1.35,y=8540.5,labels="Median")
text(x=1.35,y=8538,labels="unteres Quartil")
text(x=1.35,y=8530,labels="Ausreißer")
dev.off()

#--- Schematische Darstellung eines Histogramms
pdf(file = "Schema_hist.pdf")
hist(e11.MnMw[,7],freq=F,main="",xlab="",ylab="Dichte",ylim=c(0,0.12),xaxt="n",yaxt="n")
axis(1, at=c(seq(8528,8555,2)), labels=c(expression(c[0]),expression(c[1]),expression(c[2]),expression(c[3]),expression(c[4]),expression(c[5]),expression(c[6]),expression(c[7]),expression(c[8]),expression(c[9]),expression(c[10]),expression(c[11]),expression(c[12]),expression(c[13])))
axis(2, at=c(seq(0,0.12,0.02)), labels=c("","","","","","",""))
dev.off()

#--- Schematische Darstellung der Bandbreite bei Histogrammen
pdf(file = "Bandbreite.pdf")
hist(e11.MnMw[,9],freq=F,main="",xlab="",ylab="Dichte",xlim=c(8030,8060),ylim=c(0,0.15),xaxt="n",yaxt="n")
axis(1, at=c(seq(8030,8060,10)), labels=c("","","",""))
axis(2, at=c(seq(0,0.15,0.05)), labels=c("","","",""))
lines(density(e11.MnMw[,9], kernel="gaussian", adjust=1), lty=1)
lines(density(e11.MnMw[,9], kernel="gaussian", adjust=0.2), lty=2)
lines(density(e11.MnMw[,9], kernel="gaussian", adjust=5), lty=3)
dev.off()

#--- Plot: Abnahme Mn,Mw fuer sim1 und 1e11 Molekuele
pdf(file="MnMw_plot.pdf")
plot(c(time,time),c(e11.MnMw[1,c(1,3,5,7,9,11,13)],e11.MnMw[1,c(2,4,6,8,10,12,14)]),xlim=(c(0,3600)),ylim=(c(0,22000)),xaxt="n",yaxt="n",xlab="Zeit in Sekunden",ylab="Zahlenmittel (Kreise) und Gewichtsmittel (Dreiecke) in g/mol",pch=c(1,1,1,1,1,1,1,2,2,2,2,2,2,2))
axis(1, at=c(time), labels=c(time))
axis(2, at=c(seq(0,22000,2000)), labels=c(seq(0,22000,2000)))
dev.off()

#--- Boxplots
pdf(file = "Mn_box.pdf")
par(mfrow = c(1,3))
boxplot(e11.MnMw[,3],e10.MnMw[,3], ylim=c(9910,9950), xlab="A", ylab="Zahlenmittel in g/mol", col=c("lightgray","white"))
boxplot(e11.MnMw[,7],e10.MnMw[,7], ylim=c(8520,8560), xlab="B", ylab="Zahlenmittel in g/mol", col=c("lightgray","white"))
boxplot(e11.MnMw[,13],e10.MnMw[,13], ylim=c(7270,7310), xlab="C", ylab="Zahlenmittel in g/mol", col=c("lightgray","white"))
dev.off()

pdf(file = "Mw_box.pdf")
par(mfrow = c(1,3))
boxplot(e11.MnMw[,4],e10.MnMw[,4], ylim=c(19760,19840), xlab="A", ylab="Gewichtsmittel in g/mol", col=c("lightgray","white"), yaxt="n")
axis(2, at=c(19760,19770,19780,19790,19800,19810,19820,19830,19840), labels=c(19760,19770,19780,19790,19800,19810,19820,19830,19840))
boxplot(e11.MnMw[,8],e10.MnMw[,8], ylim=c(17300,17370), xlab="B", ylab="Gewichtsmittel in g/mol", col=c("lightgray","white"))
boxplot(e11.MnMw[,14],e10.MnMw[,14], ylim=c(15350,15400), xlab="C", ylab="Gewichtsmittel in g/mol", col=c("lightgray","white"))
dev.off()

#--- Histogramme
pdf(file="Mn_hist.pdf")
par(mfrow = c(3,2))
hist(e11.MnMw[,3], freq=F, breaks=seq(9910,9950,1), xlim=c(9910,9950), ylim=c(0,0.16), main="A: Histogramm nach 600 Sekunden", xlab="Zahlenmittel in g/mol", ylab="Dichte", col="lightgray")
lines(density(e11.MnMw[,3], kernel="gaussian"))
hist(e10.MnMw[,3], freq=F, breaks=seq(9910,9950,1), xlim=c(9910,9950), ylim=c(0,0.16), main="A: Histogramm nach 600 Sekunden", xlab="Zahlenmittel in g/mol", ylab="Dichte")
lines(density(e10.MnMw[,3], kernel="gaussian"))
hist(e11.MnMw[,7], freq=F, breaks=seq(8520,8560,1), xlim=c(8520,8560), ylim=c(0,0.16), main="B: Histogramm nach 1800 Sekunden", xlab="Zahlenmittel in g/mol",ylab="Dichte", col="lightgray")
lines(density(e11.MnMw[,7], kernel="gaussian"))
hist(e10.MnMw[,7], freq=F, breaks=seq(8520,8560,1), xlim=c(8520,8560), ylim=c(0,0.16), main="B: Histogramm nach 1800 Sekunden", xlab="Zahlenmittel in g/mol",ylab="Dichte")
lines(density(e10.MnMw[,7], kernel="gaussian"))
hist(e11.MnMw[,13], freq=F, breaks=seq(7270,7300,1), xlim=c(7270,7300), ylim=c(0,0.16), main="C: Histogramm nach 3600 Sekunden", xlab="Zahlenmittel in g/mol",ylab="Dichte", col="lightgray", xaxt="n")
axis(1, at=c(seq(7270,7300,10)), labels=c(seq(7270,7300,10)))
lines(density(e11.MnMw[,13], kernel="gaussian"))
hist(e10.MnMw[,13], freq=F, breaks=seq(7270,7300,1), xlim=c(7270,7300), ylim=c(0,0.16), main="C: Histogramm nach 3600 Sekunden", xlab="Zahlenmittel in g/mol",ylab="Dichte", xaxt="n")
axis(1, at=c(seq(7270,7300,10)), labels=c(seq(7270,7300,10)))
lines(density(e10.MnMw[,13], kernel="gaussian"))
dev.off()

pdf(file="Mw_hist.pdf")
par(mfrow = c(3,2))
hist(e11.MnMw[,4], freq=F, breaks=seq(19760,19840,2), xlim=c(19760,19840), ylim=c(0,0.10), main="A: Histogramm nach 600 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte", col="lightgray", xaxt="n")
axis(1, at=c(seq(19760,19840,10)), labels=c(seq(19760,19840,10)))
lines(density(e11.MnMw[,4], kernel="gaussian"))
hist(e10.MnMw[,4], freq=F, breaks=seq(19760,19840,2), xlim=c(19760,19840), ylim=c(0,0.10), main="A: Histogramm nach 600 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte", xaxt="n")
axis(1, at=c(seq(19760,19840,10)), labels=c(seq(19760,19840,10)))
lines(density(e10.MnMw[,4], kernel="gaussian"))
hist(e11.MnMw[,8], freq=F, breaks=seq(17300,17370,2), xlim=c(17300,17370), ylim=c(0,0.10), main="B: Histogramm nach 1800 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte",col="lightgray", xaxt="n")
axis(1, at=c(seq(17300,17370,10)), labels=c(seq(17300,17370,10)))
lines(density(e11.MnMw[,8], kernel="gaussian"))
hist(e10.MnMw[,8], freq=F, breaks=seq(17300,17370,2), xlim=c(17300,17370), ylim=c(0,0.10), main="B: Histogramm nach 1800 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte", xaxt="n")
axis(1, at=c(seq(17300,17370,10)), labels=c(seq(17300,17370,10)))
lines(density(e10.MnMw[,8], kernel="gaussian"))
hist(e11.MnMw[,14], freq=F, breaks=seq(15340,15400,2), xlim=c(15340,15400), ylim=c(0,0.10), main="C: Histogramm nach 3600 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte", col="lightgray")
lines(density(e11.MnMw[,14], kernel="gaussian"))
hist(e10.MnMw[,14], freq=F, breaks=seq(15340,15400,2), xlim=c(15340,15400), ylim=c(0,0.10), main="C: Histogramm nach 3600 Sekunden", xlab="Gewichtsmittel in g/mol", ylab="Dichte")
lines(density(e10.MnMw[,14], kernel="gaussian"))
dev.off()

#--- Konfidenzintervalle
t.test(e11.MnMw[,3])
set.seed(8462329)
t.test(e10.MnMw$V3[sample(1:2673, replace=F, size=1000)])
t.test(e11.MnMw[,7])
set.seed(2748475)
t.test(e10.MnMw$V7[sample(1:2673, replace=F, size=1000)])
t.test(e11.MnMw[,13])
set.seed(4798412)
t.test(e10.MnMw$V13[sample(1:2673, replace=F, size=1000)])

t.test(e11.MnMw[,4])
set.seed(9646379)
t.test(e10.MnMw$V4[sample(1:2673, replace=F, size=1000)])
t.test(e11.MnMw[,8])
set.seed(2542764)
t.test(e10.MnMw$V8[sample(1:2673, replace=F, size=1000)])
t.test(e11.MnMw[,14])
set.seed(8746782)
t.test(e10.MnMw$V14[sample(1:2673, replace=F, size=1000)])

#--- Zwei-Stichproben-t-Tests
set.seed(1354865)
t.test(e11.MnMw[,3],e10.MnMw$V3[sample(1:2673, replace=F, size=1000)])
set.seed(3486438)
t.test(e11.MnMw[,7],e10.MnMw$V7[sample(1:2673, replace=F, size=1000)])
set.seed(4259672)
t.test(e11.MnMw[,13],e10.MnMw$V13[sample(1:2673, replace=F, size=1000)])

set.seed(6075032)
t.test(e11.MnMw[,4],e10.MnMw$V4[sample(1:2673, replace=F, size=1000)])
set.seed(7098745)
t.test(e11.MnMw[,8],e10.MnMw$V8[sample(1:2673, replace=F, size=1000)])
set.seed(3206502)
t.test(e11.MnMw[,14],e10.MnMw$V14[sample(1:2673, replace=F, size=1000)])

#--- Varianz-Tests
set.seed(16374986)
var.test(e11.MnMw[,3],e10.MnMw$V3[sample(1:2673, replace=F, size=1000)])
set.seed(2648294)
var.test(e11.MnMw[,7],e10.MnMw$V7[sample(1:2673, replace=F, size=1000)])
set.seed(7209384)
var.test(e11.MnMw[,13],e10.MnMw$V13[sample(1:2673, replace=F, size=1000)])

set.seed(4098321)
var.test(e11.MnMw[,4],e10.MnMw$V4[sample(1:2673, replace=F, size=1000)])
set.seed(5137012)
var.test(e11.MnMw[,8],e10.MnMw$V8[sample(1:2673, replace=F, size=1000)])
set.seed(6384721)
var.test(e11.MnMw[,14],e10.MnMw$V14[sample(1:2673, replace=F, size=1000)])
